<?php
include('../dbconn.php'); // Ensure this file sets up a PDO connection in a variable, e.g., $pdo

$id = $_GET['id'];

// Prepare and execute the query securely to prevent SQL injection
$sql = "DELETE FROM `intern` WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);

if ($stmt->execute()) {
    header("location: app.php");
    exit();
} else {
    echo "<script>alert('Error deleting record');</script>";
}
?>