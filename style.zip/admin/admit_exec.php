<?php
include('../dbconn.php');

// For Cancel admission
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Update status to 'UNPAID' and admission to 'NOT ADMITTED'
    $stmt = $conn->prepare("UPDATE intern SET status = 'UNPAID' WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: app.php");
    exit;
}

// For admit user
if (isset($_GET['uid'])) {
    $uid = intval($_GET['uid']);

    // Update status to 'PAID' and admission to 'ADMITTED'
    $stmt = $conn->prepare("UPDATE intern SET status = 'PAID' WHERE id = :id");
    $stmt->bindParam(':id', $uid, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: app.php");
    exit;
}
?>
