<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>NewApplication </h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
      <li class="breadcrumb-item active">New Application</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Internship Application Records (UNPAID)</h5>
          
          <table class="table table-striped datatable">
            <thead>
              <tr>
                <th><b>#</b></th>
                <th>Fullname</th>
                <th>Sex</th>
                <th>Phone No</th>
                <th>Email</th>                   
                <th>Department</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                // Update SQL query to filter only UNPAID records
                $sql = "SELECT * FROM intern WHERE status = 'UNPAID' ORDER BY created_date ASC";
                $result = $conn->query($sql);

                if ($result->rowCount() > 0) {  // Use rowCount() to check the number of results
                  $cnt = 1;
                  while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
              ?>
                <tr>
                  <td><?php echo $cnt; ?></td>
                  <td><?php echo $row['name']; ?></td>
                  <td><?php echo $row['sex']; ?></td>
                  <td><?php echo $row['phone']; ?></td>
                  <td><?php echo $row['email']; ?></td>
                  <td><?php echo $row['department']; ?></td>
                  <td>
                    <?php if ($row['status'] == 'PAID') { ?>
                      <a href="admit_exec.php?id=<?php echo $row['id']; ?>" style="color: red">Cancel</a>
                    <?php } else { ?>
                      <a href="admit_exec.php?uid=<?php echo $row['id']; ?>">Paid</a>
                    <?php } ?> / 
                    <a href="../login/uploads/<?php echo $row['receipt']; ?>" class="View receipt" title="View receipt" data-toggle="tooltip">Receipt</a>
                  </td>
                  <td>
                    <button class="btn btn-danger"><a href="delete-user.php?id=<?php echo $row['id']; ?>" class="delete" title="delete" data-toggle="tooltip"><i class="bi bi-trash" style="color: white"></i></a></button>
                  </td>
                </tr>
              <?php 
                  $cnt++;
                  } 
                } else {
                  echo "<tr><td colspan='8'>No unpaid records found</td></tr>";
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->
<?php include('include/footer.php'); ?>
